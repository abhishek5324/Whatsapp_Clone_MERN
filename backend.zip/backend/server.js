//imports
// require('dotenv').config();
import dotenv from 'dotenv'
import express from 'express';
import mongoose from 'mongoose'; 
import Cors from 'cors';
import Messages from './dbMessages.js';
import Pusher from 'pusher';

//app config
dotenv.config();
const port = process.env.PORT || 5000;
const app = express();

const pusher = new Pusher({
    appId: "1199749",
    key: "c8bd57f1d0942fc64212",
    secret: "0cb4fe05ee1d81ea62d7",
    cluster: "ap2",
    useTLS: true
  });
const connection_url = `mongodb+srv://admin:${process.env.pass}@cluster0.pjrnm.mongodb.net/whatsappDB?retryWrites=true&w=majority`

//middleware

app.use(express.json());
app.use(Cors())

//DB config
mongoose.connect(connection_url,{
    useNewUrlParser:true,
    useCreateIndex: true,
    useUnifiedTopology: true
});

//api routes

const db = mongoose.connection
db.once("open",() => {
    console.log('DB connected');
    const msgCollection = db.collection("whatsappmessages")
    const changeStream = msgCollection.watch()

    changeStream.on('change',change => {
        console.log(change);
        if(change.operationType === 'insert')
        {
            const messageDetails = change.fullDocument
            pusher.trigger("messages","inserted", {
                message: messageDetails.message,
                name: messageDetails.name,
                timestamp:messageDetails.timestamp,
                received:messageDetails.received
            })
        }
        else{
            console.log("Error trigerring Pusher");
        }
    })
})
app.get('/',(req,res) => {
    res.send("<h1>hi</h1>")
})

app.get('/messages/sync',(req,res) => {

    Messages.find((err,data) => {
        if(err)
            res.status(500).send(err);
        else
            res.status(200).send(data);
    })
})

app.post('/messages/new',(req,res) => {
    const dbMessage = req.body;
    Messages.create(dbMessage,(err,data) => {
        if(err)
            res.status(500).send(err);
        else
            res.status(201).send(data);
    })
})
//listen
app.listen(port,(req,res) => {
    console.log("server started at port 5000");
})